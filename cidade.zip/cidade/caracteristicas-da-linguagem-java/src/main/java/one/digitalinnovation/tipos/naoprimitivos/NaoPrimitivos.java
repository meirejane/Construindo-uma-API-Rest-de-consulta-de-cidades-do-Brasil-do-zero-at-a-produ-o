package one.digitalinnovation.tipos.naoprimitivos;

public class NaoPrimitivos {

    public static void main(String[] args) {

        String texto = "Meu texto para apresentação"; //Sequência de caracteres

        Void v; //Tipo válido

        Object o = new Object();

        Number numero = Integer.valueOf(100);

        numero.toString();
    }

}
