package one.digitalinnovation.interfaces;

public class Trator implements Veiculo {

    @Override
    public String registro() {
        return "AWD12387465GFDA";
    }
}
