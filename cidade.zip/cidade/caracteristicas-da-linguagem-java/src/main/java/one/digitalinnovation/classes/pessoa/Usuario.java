package one.digitalinnovation.classes.pessoa;

import one.digitalinnovation.classes.usuario.SuperUsuario;

public class Usuario extends SuperUsuario {

    public Usuario(final String login, final String senha) {
        super(login, senha);
    }
}
